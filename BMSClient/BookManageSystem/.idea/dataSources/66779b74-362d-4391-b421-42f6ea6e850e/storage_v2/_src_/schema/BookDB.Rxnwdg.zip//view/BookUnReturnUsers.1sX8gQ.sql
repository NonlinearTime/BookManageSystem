create view BookUnReturnUsers as
  select
    `BookDB`.`BorrowReg`.`uID` AS `UserID`,
    `BookDB`.`BorrowReg`.`rID` AS `RentID`,
    `BookDB`.`BorrowReg`.`bID` AS `BookID`,
    `BookDB`.`Book`.`bName`    AS `BookName`
  from `BookDB`.`BorrowReg`
    join `BookDB`.`Book`
  where ((`BookDB`.`BorrowReg`.`isBack` = FALSE) and (now() > `BookDB`.`BorrowReg`.`rbDate`) and
         (`BookDB`.`BorrowReg`.`bID` = `BookDB`.`Book`.`bID`));


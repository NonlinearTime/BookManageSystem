create view BackReqView as
  select
    `BookDB`.`ReturnRecord`.`RentID`  AS `RentID`,
    `BookDB`.`ReturnRecord`.`UserID`  AS `UserID`,
    `BookDB`.`User`.`uName`           AS `UserName`,
    `BookDB`.`ReturnRecord`.`BookID`  AS `BookID`,
    `BookDB`.`Book`.`bName`           AS `BookName`,
    `BookDB`.`ReturnRecord`.`RetDate` AS `RetDate`,
    `BookDB`.`BorrowReg`.`rbDate`     AS `ReturnDate`
  from `BookDB`.`BorrowReg`
    join `BookDB`.`User`
    join `BookDB`.`Book`
    join `BookDB`.`ReturnRecord`
  where ((`BookDB`.`ReturnRecord`.`RentID` = `BookDB`.`BorrowReg`.`rID`) and
         (`BookDB`.`ReturnRecord`.`UserID` = `BookDB`.`User`.`uID`) and
         (`BookDB`.`ReturnRecord`.`BookID` = `BookDB`.`Book`.`bID`));


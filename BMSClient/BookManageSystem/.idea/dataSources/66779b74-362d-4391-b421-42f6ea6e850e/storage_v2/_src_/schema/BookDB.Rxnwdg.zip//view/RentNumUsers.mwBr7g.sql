create view RentNumUsers as
  select
    `BookDB`.`User`.`uID` AS `UserID`,
    count(0)              AS `RentNum`
  from `BookDB`.`BorrowReg`
    join `BookDB`.`User`
  where (`BookDB`.`User`.`uID` = `BookDB`.`BorrowReg`.`uID`)
  group by `BookDB`.`User`.`uID`;


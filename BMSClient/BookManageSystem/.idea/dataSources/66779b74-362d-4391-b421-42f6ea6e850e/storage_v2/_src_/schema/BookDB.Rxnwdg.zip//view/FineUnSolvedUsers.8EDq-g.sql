create view FineUnSolvedUsers as
  select
    `BookDB`.`FineReg`.`uID`    AS `UserID`,
    `BookDB`.`FineReg`.`fID`    AS `FineID`,
    `BookDB`.`FineReg`.`fMount` AS `FineMount`
  from `BookDB`.`FineReg`
  where (`BookDB`.`FineReg`.`isSolved` = FALSE);


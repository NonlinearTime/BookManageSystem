create view RentReqView as
  select
    `BookDB`.`RentRecord`.`RentID`     AS `RentID`,
    `BookDB`.`User`.`uID`              AS `UserID`,
    `BookDB`.`User`.`uName`            AS `UserName`,
    `BookDB`.`Book`.`bID`              AS `BookID`,
    `BookDB`.`Book`.`bName`            AS `BookName`,
    `BookDB`.`RentRecord`.`RentDate`   AS `RentDate`,
    `BookDB`.`RentRecord`.`ReturnDate` AS `ReturnDate`
  from `BookDB`.`RentRecord`
    join `BookDB`.`User`
    join `BookDB`.`Book`
  where ((`BookDB`.`RentRecord`.`UserID` = `BookDB`.`User`.`uID`) and
         (`BookDB`.`RentRecord`.`BookID` = `BookDB`.`Book`.`bID`));


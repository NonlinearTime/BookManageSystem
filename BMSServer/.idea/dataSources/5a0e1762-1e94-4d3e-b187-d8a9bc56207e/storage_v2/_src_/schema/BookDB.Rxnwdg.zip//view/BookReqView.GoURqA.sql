create view BookReqView as
  select
    `BookDB`.`Book`.`bID`     AS `BookID`,
    `BookDB`.`Book`.`bName`   AS `BookName`,
    `BookDB`.`Book`.`bType`   AS `BookType`,
    `BookDB`.`Book`.`aName`   AS `AuthorName`,
    `BookDB`.`Book`.`pubName` AS `PubName`,
    `BookDB`.`Book`.`uDate`   AS `PubDate`,
    `BookDB`.`Book`.`totNum`  AS `TotNum`,
    `BookDB`.`Book`.`rNum`    AS `LeftNum`,
    `BookDB`.`Book`.`price`   AS `Price`,
    `BookDB`.`Book`.`bScore`  AS `Score`,
    `BookDB`.`Book`.`reviews` AS `Reviews`
  from `BookDB`.`Book`;


create view UserReqView as
  select
    `BookDB`.`User`.`uID`   AS `UserID`,
    `BookDB`.`User`.`uName` AS `UserName`,
    `BookDB`.`User`.`uPwd`  AS `UserPwd`,
    `BookDB`.`User`.`email` AS `UserEmail`,
    `BookDB`.`User`.`uTele` AS `UserTele`,
    `BookDB`.`User`.`uType` AS `UserJob`,
    `BookDB`.`User`.`rTime` AS `UserRegisterTime`
  from `BookDB`.`User`;


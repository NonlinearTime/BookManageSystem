create view FineReqView as
  select
    `BookDB`.`FineReg`.`fID`    AS `FineID`,
    `BookDB`.`FineReg`.`rID`    AS `RentID`,
    `BookDB`.`User`.`uID`       AS `UserID`,
    `BookDB`.`User`.`uName`     AS `UserName`,
    `BookDB`.`FineReg`.`fMount` AS `FineMount`,
    `BookDB`.`FineReg`.`fDate`  AS `FineDate`
  from `BookDB`.`FineRecord`
    join `BookDB`.`FineReg`
    join `BookDB`.`User`
  where ((`BookDB`.`FineRecord`.`fineID` = `BookDB`.`FineReg`.`fID`) and
         (`BookDB`.`FineReg`.`uID` = `BookDB`.`User`.`uID`));

